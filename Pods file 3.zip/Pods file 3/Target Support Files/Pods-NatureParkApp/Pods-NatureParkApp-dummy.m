#import <Foundation/Foundation.h>
@interface PodsDummy_Pods_NatureParkApp : NSObject
@end
@implementation PodsDummy_Pods_NatureParkApp
@end
