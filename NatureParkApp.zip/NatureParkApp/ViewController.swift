//
//  ViewController.swift
//  NatureParkApp
//
//  Created by Austin Rath on 4/25/18.
//  Copyright © 2018 Austin Rath. All rights reserved.
//

import UIKit
import SafariServices

class ViewController: UIViewController {
    
    // FIXME: Download data base and option for uptdates
    // TODO: checkoff list of birds seen
    // TODO: connect to other bird watching website to mark birds
    // TODO: Upload user photo and description suggestions
    // TODO: vary for traits and sizes (iPad especially)
    // TODO: Launch Screen

    @IBOutlet weak var birdGuideButton: UIButton!
    @IBOutlet weak var birdGuideButtonBackground: UIView!
    @IBOutlet weak var buttonBackground: UIView!
    
    

    @IBAction func Website(_ sender: AnyObject) {
        if let url = URL(string: "https://www.coppellnaturepark.org") {
            let safariViewController = SFSafariViewController(url: url)
            present(safariViewController, animated: true, completion: nil)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        birdGuideButtonBackground.layer.cornerRadius = 20
        buttonBackground.layer.cornerRadius = 20
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        }
}



