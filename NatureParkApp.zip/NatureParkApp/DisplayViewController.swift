//
//  DisplayViewController.swift
//  NatureParkApp
//
//  Created by Austin Rath on 4/30/18.
//  Copyright © 2018 Austin Rath. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseStorage
import AVFoundation

class DisplayViewController: UIViewController {
    // View Controller outlets
    @IBOutlet weak var birdImage: UIImageView!
    @IBOutlet weak var birdDescriptionLabel: UILabel!
    @IBOutlet weak var audioButton: UIButton!
    
    // audio
    var audioPlayer = AVPlayer()
    var audioPlayerItem:AVPlayerItem?
    
    // Database set up
    var ref:DatabaseReference?
    var databaseHandle:DatabaseHandle?
    
    var birdName: String = ""
    var birdPic: UIImage? = UIImage(named: "birdPlaceholder")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // storage set up & reference
        let storage = Storage.storage()
        let storageRef = storage.reference()
        
        // database reference
        ref = Database.database().reference()
        
        // Set up the View using the birdName variable which contains the bird name of the selected tableViewCell
        let birdRef = self.ref?.child("Bird Names/\(birdName)")
        databaseHandle = birdRef?.observe(.value, with: { (snapshot) in
            if let description = snapshot.value as? String {
                self.birdDescriptionLabel.text = description
                
                
                 // streaming audio
                let audioRef = storageRef.child("BirdAudio/\(self.birdName).mp3")
                audioRef.downloadURL(completion: { (url, error) in
                    if let error = error {
                        print(error.localizedDescription)
                        self.audioButton.isEnabled = false
                        
                        self.audioButton.setTitle("Audio unavailable", for: .disabled)
                    } else {
                        
                        self.audioPlayerItem = AVPlayerItem(url: url!)
                        self.audioPlayer = AVPlayer(playerItem: self.audioPlayerItem)

                    }
                })
 
                
                /*
                // downloading audio onto device
                let audioRef = storageRef.child("BirdAudio/\(self.birdName).mp3")
                audioRef.getData(maxSize: 1*1024*1024, completion: { (data, error) in
                    if let error = error {
                        print(error.localizedDescription)
                        self.audioButton.isEnabled = false
                        self.audioButton.setTitle("Audio unavailable", for: .disabled)

                    } else {
                        if data {
                            self.audioPlayerItem = AVPlayer()
                        }
                    }
                })
                */
            }
        })
        birdImage.image = birdPic
      //  birdDescriptionLabel.text =  self.birdDescriptionLabel.text
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func audioButtonPressed(_ sender: Any) {
        if audioPlayer.rate == 0 {
            audioPlayer.play()
            if audioPlayer.currentTime() == audioPlayer.currentItem?.asset.duration {
                audioPlayer.seek(to: kCMTimeZero)
                audioPlayer.play()
            }
                
            
        } else {
            audioPlayer.pause()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        audioPlayer.pause()
        audioPlayer.seek(to: kCMTimeZero)

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
