//
//  BirdTableViewController.swift
//  NatureParkApp
//
//  Created by Austin Rath on 4/25/18.
//  Copyright © 2018 Austin Rath. All rights reserved.
//

import UIKit
import FirebaseDatabase
import FirebaseStorage

class BirdTableViewController: UITableViewController, UISearchResultsUpdating {

    
    // Set up array of birdNames with type Strings and birdDictionary with string:UIImage type
    var birdNames:[String] = []
    var birdDictionary: [String: UIImage] = [:]
    
    // database set up
    var ref:DatabaseReference?
    var databaseHandle:DatabaseHandle?
    
    // used to pass info to the displayViewController
    var myIndex: Int = 0
    
    // search bar and filtered arrays
    let searchController = UISearchController(searchResultsController: nil)
    var filteredBirds: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // navigation item title
        navigationItem.title = "Bird Guide"
        
        // search controller set up
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
        
        
        // database and storage set up/ reference
        ref = Database.database().reference()
        let storage = Storage.storage()
        let storageRef = storage.reference()
        
        // Loop through all items in database BirdNames and fill out the birdNames array and birdDictionary dictionary
        databaseHandle = self.ref?.child("Bird Names").observe(.childAdded, with: { (snapshot) in
            // code to run when child is added add key of database to birdNames
            self.birdNames += [snapshot.key]
            self.filteredBirds = self.birdNames
            self.tableView.reloadData()
            
            
            // use the key string value to obtain the bird Images and put them into the bird Dictionary with the snapshot.key as the reference
            
            let birdRef = storageRef.child("BirdPictures/\(snapshot.key).png")
            birdRef.getData(maxSize: 1*1024*1024, completion: { (data, error) in
                if let error = error {
                    print (error.localizedDescription)
                    self.birdDictionary[snapshot.key] = UIImage(named: "birdPlaceholder")
                    self.tableView.reloadData()
                } else {
                    self.birdDictionary[snapshot.key] = UIImage(data: data!)
                    self.tableView.reloadData()
                }
            })
            
            
        })
        
        
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    func updateSearchResults(for searchController: UISearchController) {
        if searchController.searchBar.text! == "" {
            self.filteredBirds = birdNames
        } else {
            self.filteredBirds = []
            for name in birdNames {
                if name.lowercased().contains(searchController.searchBar.text!.lowercased()) {
                    self.filteredBirds += [name]
            }
            
        }
    }
      self.tableView.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
       
        return filteredBirds.count
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        // height of each tableViewCell
        return 120
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // load each cell, returns UITableViewCell
        let cell = tableView.dequeueReusableCell(withIdentifier: "BirdCell2", for: indexPath) as! BirdTableViewCell
        
        cell.birdTabelLabel?.text = filteredBirds[indexPath.row]
        if birdDictionary.count >= indexPath.row {
            cell.birdTableImage?.image = birdDictionary[filteredBirds[indexPath.row]]
        }
        
    
        return cell
    }
    

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myIndex = indexPath.row
        performSegue(withIdentifier: "DisplaySegue", sender: self)
    }
    
   override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    // send data to the DisplayViewController so it can display correct information
    if segue.identifier == "DisplaySegue" {
        let DisplayViewController = segue.destination as! DisplayViewController
        DisplayViewController.birdName = filteredBirds[myIndex]
        DisplayViewController.birdPic = birdDictionary[filteredBirds[myIndex]]
        segue.destination.navigationItem.title = filteredBirds[myIndex]
    }
    

    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
}
